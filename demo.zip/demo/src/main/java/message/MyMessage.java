package message;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import response.Myresponse;

@RestController
public class MyMessage {

    @GetMapping("/jsonproof")
    public Myresponse message() {
       
        Myresponse response = new Myresponse(1, "Pranesh", "Ramachnadran");
        return response; 
    }
}

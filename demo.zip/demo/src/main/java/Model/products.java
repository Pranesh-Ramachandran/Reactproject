package Model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class products {
@Id
 int productid;
String productname;
String description;
public int getProductid() {
    return productid;
}
public void setProductid(int productid) {
    this.productid = productid;
}
public String getProductname() {
    return productname;
}
public void setProductname(String productname) {
    this.productname = productname;
}
public String getDescription() {
    return description;
}
public void setDescription(String description) {
    this.description = description;
}
public products(int productid, String productname, String description) {
    this.productid = productid;
    this.productname = productname;
    this.description = description;
}
public products() {
}
}

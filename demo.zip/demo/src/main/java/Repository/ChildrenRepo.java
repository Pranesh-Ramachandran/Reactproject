package Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import Model.Children;


@Repository
public interface ChildrenRepo extends JpaRepository<Children,Integer>{
    
    @Modifying
    @Query("select c from Children c")
    public List<Children> save();
    
    // @Query("select c from Children c where c.name = 1")
    // public List<Children> findbyid();

    
}

package Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import Service.ProductService;
import Model.products;

@RestController
@RequestMapping("/products") 
public class ProductController {

    @Autowired
    private ProductService obj;

    @PostMapping("/posting")
    public ResponseEntity<products> addProducts(@RequestBody products a) {
        return new ResponseEntity<>(obj.addProducts(a), HttpStatus.CREATED);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<products> getProductById(@PathVariable int id) {
        products product = obj.getProductById(id);
        return product != null ? 
               new ResponseEntity<>(product, HttpStatus.OK) : 
               new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("/all")
    public ResponseEntity<List<products>> getAllProducts() {
        return new ResponseEntity<>(obj.getAllProducts(), HttpStatus.OK);
    }

    @PutMapping("/updating/{id}")
    public ResponseEntity<products> updateProduct(@PathVariable int id, @RequestBody products updatedProduct) {
        products product = obj.editProduct(id, updatedProduct.getProductname(), updatedProduct.getDescription());
        return product != null ? 
               new ResponseEntity<>(product, HttpStatus.OK) : 
               new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable int id) {
        return obj.deleteProduct(id) ? 
               new ResponseEntity<>(HttpStatus.NO_CONTENT) : 
               new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

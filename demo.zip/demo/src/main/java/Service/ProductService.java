package Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Model.products;
import Repository.ProductRepo;
@Service
public class ProductService {
    @Autowired
  ProductRepo obj;
  public products addProducts(Model.products a)
  {
    return obj.save(a);
  }
  

  public Model.products getProductById(int productId) {
    return obj.findById(productId).orElse(null);
}

public List<Model.products> getAllProducts() {
    return obj.findAll();
}

public Model.products editProduct(int productId, String productName, String description) {
    Model.products existingProduct = obj.findById(productId).orElse(null);
    if (existingProduct != null) {
        existingProduct.setProductname(productName);
        existingProduct.setDescription(description);
        return obj.save(existingProduct);
    } else {
        return null;
    }
}

public boolean deleteProduct(int productId) {
    if (obj.existsById(productId)) {
        obj.deleteById(productId);
        return true;
    }
    return false;
}

  
}
